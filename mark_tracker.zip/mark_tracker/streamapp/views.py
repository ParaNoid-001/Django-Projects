from django.shortcuts import get_object_or_404, render, redirect
from django.http import HttpResponse, JsonResponse
from .models import Stream
from django.contrib import messages  # For success/error notifications

def stream_list(request):
    streams = Stream.objects.all()
    return render(request, "streamapp/add_stream.html", {"streams": streams})

def add_stream(request):
    if request.method == "POST":
        stream_name = request.POST.get("stream_name")  # Get the stream name from the form
        if stream_name:  # Validate input
            if not Stream.objects.filter(name=stream_name).exists():  # Ensure uniqueness
                Stream.objects.create(name=stream_name)
                messages.success(request, "Stream created successfully!")
                 # Get the updated list of streams
                streams = Stream.objects.all()
                print(streams)
                stream_data = [
                    {"id": stream.id, "name": stream.name} for stream in streams
                ]
                return JsonResponse({
                    "streams": stream_data,
                })
            else:
                return JsonResponse({"message": "Stream with this name already exists."}, status=400)
        else:
            return JsonResponse({"message": "Stream name cannot be empty!"}, status=400)
    return render(request, "streamapp/add_stream.html")

def edit_stream(request, pk=None):
    stream = get_object_or_404(Stream, pk=pk) if pk else None

    if request.method == "POST":
        name = request.POST.get("stream_name")

        if name and stream:
            stream.name = name
            stream.save()
            
            messages.success(request, "Stream updated successfully!")
            # Get all streams and return as JSON
            streams = Stream.objects.all()
            stream_data = [{"id": s.id, "name": s.name} for s in streams]

            return JsonResponse({"streams": stream_data})  # Return updated streams as JSON

        return JsonResponse({"message": "Stream name cannot be empty."}, status=400)

    streams = Stream.objects.all()
    return render(request, "streamapp/add_stream.html", {"stream": stream, "streams": streams})


def delete_stream(request, pk):
    stream = get_object_or_404(Stream, pk=pk)
    stream.delete()
    messages.success(request, "Stream deleted successfully.")
    return redirect("stream_list")
