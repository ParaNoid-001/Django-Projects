from django.urls import path
from . import views

urlpatterns=[
    path("", views.stream_list, name="stream_list"),
    path('add/', views.add_stream, name='add_stream'),
    path("edit/<int:pk>/", views.edit_stream, name="edit_stream"),
    path("delete/<int:pk>/", views.delete_stream, name="delete_stream"),
]