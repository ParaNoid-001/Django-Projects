from django.db import models

class Stream(models.Model):
    name = models.CharField(max_length=100, unique=True, help_text="Name of the stream (e.g., Science, Commerce, Arts)")

    def __str__(self):
        return self.name
