from django.contrib import admin
from streamapp.models import Stream

admin.site.register(Stream)
