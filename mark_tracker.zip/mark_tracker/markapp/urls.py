from django.urls import path
from . import views

urlpatterns=[
    path('apply/', views.apply_mark, name='apply'),
    path('get-subjects/', views.get_subjects, name='get_subjects'),
        
]