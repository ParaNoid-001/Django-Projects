from django.shortcuts import render
from django.http import JsonResponse
from .models import Mark
from streamapp.models import Stream
from subjectapp.models import Subject
from registerapp.models import Student

def get_subjects(request):
    stream_id = request.GET.get("stream_id")
    if not stream_id:
        return JsonResponse({"message": "Stream ID is required."}, status=400)

    try:
        # Fetch subjects based on the provided stream ID
        subjects = Subject.objects.filter(stream_id=stream_id).values("id", "name")
        students = Student.objects.filter(stream_id=stream_id).values("roll_number", "first_name", "last_name")
        return JsonResponse({"subjects": list(subjects), "students": list(students)})    

    except Stream.DoesNotExist:
        return JsonResponse({"message": "Invalid stream ID."}, status=400)
      
def apply_mark(request):
    if request.method == "POST":
        stream_id = request.POST.get("stream")
        subject_id = request.POST.get("subject")
        student_id = request.POST.get("student")
        marks = request.POST.get("marks")

        print(stream_id, subject_id, student_id, marks)

        # Validate inputs
        if not all([stream_id, subject_id, student_id, marks]):
            return JsonResponse({"message": "All fields are required."}, status=400)

        try:
            stream = Stream.objects.get(id=stream_id)
            subject = Subject.objects.get(id=subject_id)
            student = Student.objects.get(roll_number=student_id)

            print(stream, subject, student)

            # Check for uniqueness
            if Mark.objects.filter(student=student, subject=subject).exists():
                return JsonResponse({"message": "Marks for this student and subject already exist."}, status=400)

            # Save marks to the database
            Mark.objects.create(student=student, subject=subject, stream=stream, marks=marks)
            return JsonResponse({"message": "Marks applied successfully!"})
        except (Stream.DoesNotExist, Subject.DoesNotExist, Student.DoesNotExist):
            return JsonResponse({"message": "Invalid data provided."}, status=400)
    else:
        streams = Stream.objects.all()

    return render(request, "markapp/apply_mark.html", {"streams": streams})



