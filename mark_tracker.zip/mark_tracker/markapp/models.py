from django.db import models
from streamapp.models import Stream
from subjectapp.models import Subject
from registerapp.models import Student

class Mark(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="marks", help_text="Student related to the marks")
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name="marks", help_text="Subject related to the marks")
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name="marks", help_text="Stream of the student")
    marks = models.DecimalField(max_digits=5, decimal_places=2, help_text="Marks obtained in the subject")

    class Meta:
        unique_together = ("student", "subject")  # Prevent duplicate entries for the same student and subject combination.

    def __str__(self):
        return f"{self.student.roll_number} - {self.subject.name} - {self.marks}"
