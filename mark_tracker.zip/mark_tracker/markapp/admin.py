from django.contrib import admin
from markapp.models import Mark

admin.site.register(Mark)
