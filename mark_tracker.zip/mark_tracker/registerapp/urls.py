from django.urls import path
from . import views

urlpatterns=[
    path('', views.main_menu, name='main_menu'),
    path('add_student/', views.add_student, name='add_student'),
    # path('search/id/', views.search_student_by_id, name='search_student_by_id'),
    # path('search/name/', views.search_student_by_name, name='search_student_by_name'),
    # path('highest/', views.highest_score_student, name='highest_score_student')
]