from django.shortcuts import render
from django.http import JsonResponse
from .models import Student
from streamapp.models import Stream

def main_menu(request):
    return render(request, 'registerapp/home.html')

def add_student(request):
    if request.method == "POST":
        # Extract data from POST request
        roll_number = request.POST.get("roll_number")
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        date_of_birth = request.POST.get("date_of_birth")
        stream_id = request.POST.get("stream")

        # Validate inputs
        if not all([roll_number, first_name, last_name, email, date_of_birth, stream_id]):
            return JsonResponse({"message": "All fields are required."}, status=400)
        
        try:
            stream = Stream.objects.get(id=stream_id)
            if Student.objects.filter(roll_number=roll_number).exists():
                return JsonResponse({"message": "Roll number already exists."}, status=400)

            if Student.objects.filter(email=email).exists():
                return JsonResponse({"message": "Email already exists."}, status=400)

            # Save student to the database
            Student.objects.create(
                roll_number=roll_number,
                first_name=first_name,
                last_name=last_name,
                email=email,
                date_of_birth=date_of_birth,
                stream=stream,
            )

            return JsonResponse({"message": "Student registered successfully!"})

        except Stream.DoesNotExist:
            return JsonResponse({"message": "Invalid stream selected."}, status=400)
    else:
        streams = Stream.objects.all()
    return render(request, "registerapp/add_student.html", {"streams": streams})