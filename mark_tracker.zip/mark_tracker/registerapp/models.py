from django.db import models
from streamapp.models import Stream

class Student(models.Model):
    roll_number = models.CharField(max_length=20, primary_key=True, help_text="Unique roll number for the student")
    first_name = models.CharField(max_length=100, help_text="First name of the student")
    last_name = models.CharField(max_length=100, help_text="Last name of the student")
    email = models.EmailField(unique=True, help_text="Email address of the student")
    date_of_birth = models.DateField(help_text="Date of birth of the student")
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name="students", help_text="Stream the student belongs to")

    def __str__(self):
        return f"{self.roll_number} - {self.first_name} {self.last_name}"



