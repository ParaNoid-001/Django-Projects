$(document).ready(function () {

    // Stream Register
    $("#stream_register_btn").click(function (event) {
        event.preventDefault(); // Prevent default form submission
        
        // Get the value from the input field
        const stream_id = $("#stream_id").val();
        const stream_name = $("#stream_name").val();
        console.log("Name: " + stream_name);
    
        $.ajax({
            // Dynamically choose the URL based on whether it's an edit or add
            url: stream_id ? `/stream/edit/${stream_id}/` : `/stream/add/`,
            method: "POST",
            data: {
                stream_id: stream_id,
                stream_name: stream_name,
                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val() // Include CSRF token
            },
            success: function (response) {
                // Clear the input field and display success message
                $("#stream_name").val("");
                $("#acknowledge").css("color", "green");
                
                // Dynamically update the table with the new list of streams
                const streamList = $("#streamList");
                streamList.empty(); // Clear the table
    
                // Add rows for each stream in the response
                // response.streams.forEach(function(stream) {
                //     streamList.append(
                //         `<tr>
                //             <td>${stream.name}</td>
                //             <td>
                //                 <a href="/stream/edit/${stream.id}/" class="btn btn-warning btn-sm">Edit</a>
                //             </td>
                //             <td>
                //                 <form action="/stream/delete/${stream.id}/" method="post" onsubmit="return confirm('Are you sure you want to delete this stream?');">
                //                     {% csrf_token %}
                //                     <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                //                 </form>
                //             </td>
                //         </tr>`
                //     );
                // });
    
                // Optionally, redirect the user back to the list page (not needed in your case if you use AJAX)
                window.location.href = "/stream/"; // This would reload the page and show the updated list
            },
            error: function (error) {
                // Display the error message returned from Django
                const errorMessage = error.responseJSON.message || "An error occurred.";
                $("#acknowledge").text(errorMessage);
                $("#acknowledge").css("color", "red");
            }
        });
    });
    
    // Subject Register
    $("#subject_register_btn").click(function (event) {
        event.preventDefault(); // Prevent default form submission
        
        const stream_id = $("#stream").val(); 
        const subject_name = $("#subject_name").val();

        console.log("Name: " + subject_name);
        $.ajax({
            url: "/subject/add_subject/",
            method: "POST",
            data: {
                stream: stream_id,
                subject_name: subject_name,
                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val() // Include CSRF token
            },
            success: function (response) {
                $("#acknowledge").text(response.message);  
                $("#acknowledge").css("color", "green");  
            },
            error: function (error) {
                // Display the error message returned from Django
                const errorMessage = error.responseJSON.message || "An error occurred.";
                $("#acknowledge").text(errorMessage);  
                $("#acknowledge").css("color", "red");  
            }
        });
    });

    // Student Register
    $("#student_register_btn").click(function (event) {
        event.preventDefault(); 

        const roll_number = $("#roll_number").val();
        const first_name = $("#first_name").val();
        const last_name = $("#last_name").val();
        const email = $("#email").val();
        const date_of_birth = $("#date_of_birth").val();
        const stream = $("#stream").val();

        $.ajax({
            url: "/add_student/",
            method: "POST",
            data: {
                roll_number: roll_number,
                first_name: first_name,
                last_name: last_name,
                email: email,
                date_of_birth: date_of_birth,
                stream: stream,
                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
            },
            success: function (response) {
                $("#acknowledge").text(response.message);
                $("#acknowledge").css("color", "green"); // Success styling
            },
            error: function (xhr) {
                const errorMessage = xhr.responseJSON.message || "An error occurred.";
                $("#acknowledge").text(errorMessage);
                $("#acknowledge").css("color", "red"); // Error styling
            }
        });
    });

    // Fetch students based on selected stream
    $("#stream").change(function () {
        const streamId = $(this).val();
        if (streamId) {
            $.ajax({
                url: "/mark/get-subjects/",
                method: "GET",
                data: { stream_id: streamId },
                success: function (response) {
                    // Update subject dropdown
                    const subjectDropdown = $("#subject");
                    subjectDropdown.empty();
                    subjectDropdown.append('<option value="">Select Subject</option>');
                    response.subjects.forEach(subject => {
                        subjectDropdown.append(`<option value="${subject.id}">${subject.name}</option>`);
                    });

                    // Update student dropdown
                    const studentSelect = $("#student");
                    studentSelect.empty();
                    studentSelect.append('<option value="">Select Student</option>');
                    response.students.forEach(student => {
                        studentSelect.append(`<option value="${student.roll_number}">${student.roll_number} - ${student.first_name} ${student.last_name}</option>`);
                    });
                },
                error: function () {
                    alert("Error fetching subjects for the selected stream.");
                }
            });
        } else {
            // Reset subject dropdown if no stream is selected
            $("#subject").empty().append('<option value="">Select Subject</option>');
        }
    });

    // Apply Mark
    $("#apply_mark_btn").click(function (event) {
        event.preventDefault(); // Prevent default form submission
        const stream = $("#stream").val();
        const subject = $("#subject").val();
        const student = $("#student").val();
        const marks = $("#marks").val();

        console.log("Data sent to server:", {
            stream: stream,
            subject: subject,
            student: student,
            marks: marks
        });

        // AJAX POST request
        $.ajax({
            url: "/mark/apply/",
            method: "POST",
            data: {
                stream: stream,
                subject: subject,
                student: student,
                marks: marks,
                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
            },
            success: function (response) {
                $("#acknowledge").text(response.message);
                $("#acknowledge").css("color", "green");
            },
            error: function (xhr) {
                const errorMessage = xhr.responseJSON.message || "An error occurred.";
                $("#acknowledge").text(errorMessage);
                $("#acknowledge").css("color", "red");
            }
        });
    });
});




