from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),

    # Include URLs of each app
    path("", include("registerapp.urls")),
    path("stream/", include("streamapp.urls")),
    path("subject/", include("subjectapp.urls")),
    path("mark/", include("markapp.urls")),
]
