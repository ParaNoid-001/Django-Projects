from django.contrib import admin
from subjectapp.models import Subject

admin.site.register(Subject)
