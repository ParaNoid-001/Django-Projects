from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from .models import Stream, Subject
from django.contrib import messages  # For success/error notifications

def add_subject(request):
    if request.method == "POST":
        stream_id = request.POST.get("stream")
        subject_name = request.POST.get("subject_name")

        if subject_name and stream_id:  # Validate input
            try:
                stream = Stream.objects.get(id=stream_id)
                
                # Check if a subject with the same name already exists for the selected stream
                if Subject.objects.filter(name=subject_name, stream=stream).exists():
                    return JsonResponse({"message": "Subject with this name already exists for the selected stream."}, status=400)
                
                # Create the subject with the foreign key reference to the selected stream
                Subject.objects.create(name=subject_name, stream=stream)
                return JsonResponse({"message": "Subject added successfully!"})
            except Stream.DoesNotExist:
                return JsonResponse({"message": "Stream not found."}, status=400)
        else:
            return JsonResponse({"message": "Subject name cannot be empty!"}, status=400)
    streams = Stream.objects.all()
    return render(request, "subjectapp/add_subject.html", {"streams": streams})
