from django.db import models
from streamapp.models import Stream

class Subject(models.Model):
    name = models.CharField(max_length=100, unique=True, help_text="Name of the subject (e.g., Mathematics, Physics)")
    stream = models.ForeignKey(Stream, on_delete=models.CASCADE, related_name="subjects", help_text="Stream associated with this subject")

    def __str__(self):
        return f"{self.name} - {self.stream.name}"
